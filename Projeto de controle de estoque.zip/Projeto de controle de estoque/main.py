#Importando bibliotecas a serem ultilizadas
import csv
import os
import time
import pandas as pd
from art import *
from datetime import datetime
from dateutil import tz

# Nome dos arquivos csv
login_arquivo = 'Login.csv'
produto_arquivo = 'Produto.csv'
gerente_arquivo = 'Gerente.csv'
qtdUsuarios = 0

#Criar e verificar existência do arquivo de login
if not os.path.exists("Login.csv"):
  with open(login_arquivo, 'w', newline='') as arquivo:
    escrevendo = csv.writer(arquivo)
    # Cabeçalho de cada lista
    escrevendo.writerow(['Login', 'Senha', 'Função'])

#Criar e verificar existência do arquivo de Produto
if not os.path.exists("Produto.csv"):
  with open(produto_arquivo, 'w', newline='') as arquivo:
    escrevendo = csv.writer(arquivo)
    #Cabeçalho de cada lista
    escrevendo.writerow(['Nome do Produto', 'Quantidade'])

#Criar e verificar existência do arquivo do 'Gerente'
if not os.path.exists('Gerente.csv'):
  with open(gerente_arquivo, 'w', newline='') as arquivo:
    escrevendo = csv.writer(arquivo)
    #Cabeçalho de cada lista
    escrevendo.writerow(['Produto', 'Entrada & Saída', 'Quantidade','Data & Hora'])

#Criando DataFrame
Usuario_df = pd.read_csv(login_arquivo)
Produtos_df = pd.read_csv(produto_arquivo)
relatorio_df = pd.read_csv(gerente_arquivo)

#
Usuario_df['Senha'] = Usuario_df['Senha'].astype(str)

#Funções
def clear():
  os.system('cls' if os.name == 'nt' else 'clear')


def delay(x):
  time.sleep(x)


def imprimir(x):
  a = text2art(x)
  print(a)


#Tela inicial
while True:
  cont = 0
  while cont < 3:
    clear()
    imprimir("Carregando")
    delay(0.5)
    clear()
    imprimir("Carregando.")
    delay(0.5)
    clear()
    imprimir("Carregando..")
    delay(0.5)
    clear()
    imprimir("Carregando...")
    delay(0.5)
    clear()
    cont += 1
  imprimir("Sistema  de  Controle  de  estoque  iniciando")
  delay(3)
  clear()
  imprimir("Início: ")
  print("1.Cadastrar\n2.Login\n3.Sair")
  resposta = int(input(""))
  clear()

  #Cadastro
  if (resposta == 1):
    while True:
      imprimir("Cadastro:")
      print("Login:")
      login = input("")
      print("Senha:")
      senha = input("")
      print(
          "Qual é a sua função?\n 'VE.Vendedor'\n 'CP.Comprador'\n 'ES.Estoquista'\n 'GR.Gerente'\n"
      )
      funcao = input('').upper()
      qtdUsuarios += 1

      #Se o usuario ja estiver em uso
      if login in Usuario_df['Login'].values:
        delay(0.5)
        print("Nome de usuario em uso")
        delay(1.5)
        clear()

      #Caso ao contrario
      else:
        Usuario_df.loc[len(Usuario_df)] = [login, senha, funcao]
        resposta = input(
            "Quer cadastrar mais um usuario? 's' ou 'n'\n").upper()
        if (resposta == 'S'):
          clear()
        else:
          break

  #Login
  elif (resposta == 2):
    while True:
      indice = 0
      #Tela de Login
      clear()
      print("Continuar? 'S' ou 'N'")
      resposta = input('').upper()
      if (resposta == "S"):
        clear()
        imprimir('Login')
        print("usuario: ")
        login = input('')
        print("Senha:")
        senha = input('')
        #Verificando o login
        if login in Usuario_df['Login'].tolist():
          for i in range(len(Usuario_df)):
            if Usuario_df.at[i, 'Login'] == login:
              break
            else:
              indice += 1
          #Comparando com o indice do login
          if senha == Usuario_df['Senha'][indice]:
            clear()

            #'Estoquista'
            if Usuario_df['Função'][indice] == "ES":
              while True:
                clear()
                imprimir('Estoquista')
                print("O que quer fazer?\n'1.Cadastrar Produto'\n'2.sair'")
                resposta = int(input(''))
                if (resposta == 1):
                  clear()
                  imprimir("Produtos   cadastrados")
                  print(Produtos_df)
                  input('')
                  clear()
                  print("Qual Produto quer cadastrar?")
                  produto = input('')
                  print('Quantidade:')
                  quant = int(input(''))
                  Produtos_df.loc[len(Produtos_df)] = [produto, quant]
                  Produtos_df.to_csv('Produto.csv', index=False)
                  clear()
                  print("Produto cadastrado")
                  print(Produtos_df)
                  input('')

                  #Pegando data e hora brasilia
                  brasilia_tz = tz.gettz('America/Sao_Paulo')

                  # Obtendo a data e a hora atuais em Brasília
                  brasilia_time = datetime.now(brasilia_tz)

                  # Salvando a data e a hora em um DataFrame
                  data = {
                      'Data': [brasilia_time.strftime("%d/%m/%Y")],
                      'Hora': [brasilia_time.strftime("%H:%M:%S")]
                  }
                  
                  relatorio_df.loc[len(relatorio_df)] = [produto, 0, quant, data]
                  
                  clear()
                else:
                  break

            #'Comprador'
            elif Usuario_df['Função'][indice] == 'CP':
              while True:
                indice_produto = 0
                #Tela do comprador
                clear()
                imprimir('Comprador')               
                print("O que quer fazer?\n'1.Atualizar entrada'\n'2.sair'")
                resposta = int(input(''))

                #Se a resposta for um
                if (resposta == 1):
                    clear()
                    imprimir("Produtos cadastrados")
                    print(Produtos_df)
                    input()
                    clear()
                    #Pesquisando Produto
                    print("Qual é o nome do produto?")
                    produto = input('')
  
                    #Pegando o indice do produto
                    if produto in Produtos_df['Nome do Produto'].tolist():
                      for i in range(len(Produtos_df)):
                        if Produtos_df.at[i, 'Nome do Produto'] == produto:
                          break
                        else:
                          indice_produto += 1
    
                      clear()
    
                      #perguntando sobre a quantidade que vai entrar
                      print("Qual a quantidade a ser inserida do produto?")
                      nova_quantidade = int(input(''))
                      if nova_quantidade > Produtos_df.at[indice_produto, 'Quantidade']:
                        print("Valor maior do que tem no estoque")
    
                      #Somando com a quantidade anterior
                      valor_anterior = Produtos_df.at[indice_produto, 'Quantidade']
                      quantidade_produto = valor_anterior + nova_quantidade
  
                      #Pegando data e hora brasilia
                      brasilia_tz = tz.gettz('America/Sao_Paulo')
    
                      # Obtendo a data e a hora atuais em Brasília
                      brasilia_time = datetime.now(brasilia_tz)
    
                      # Salvando a data e a hora em um DataFrame
                      data = {
                          'Data': [brasilia_time.strftime("%d/%m/%Y")],
                          'Hora': [brasilia_time.strftime("%H:%M:%S")]
                      }
    
                      #Colocando no DataFrame
                      Produtos_df.at[indice_produto,'Quantidade'] = quantidade_produto
                      relatorio_df.loc[len(relatorio_df)] = [produto, nova_quantidade, quantidade_produto, data]
                      relatorio_df.to_csv('Gerente.csv', index=False)
                      Produtos_df.to_csv('Produto.csv', index=False)
                      clear()
                      print("Produto Atualizado com sucesso")
                      print(Produtos_df)
                      input()
                      clear()
                    #Caso o produto não for encontrado
                    else:
                      print("Produto não encontrado")
                      delay(2.5)
                #Outra resposta
                else:
                  break

            #'Vendedor'
            elif Usuario_df['Função'][indice] == 'VE':
              while True:
                indice_produto = 0
                #Tela do comprador
                clear()
                imprimir('Vendedor')
                print("O que quer fazer?\n'1.Atualizar saída'\n'2.sair'")
                resposta = int(input(''))
                #Se a resposta for um
                if (resposta == 1):
                  while True:
                    clear()
                    a = input("Quer continuar? 's' ou 'n'").upper()
                    if(a == 'S'):
                      indice_produto = 0
                      clear()
                      imprimir("Produtos   cadastrados")
                      print(Produtos_df)
                      input()
                      clear()
                      #Pesquisando Produto
                      print("Qual é o nome do produto?")
                      produto = input('')
    
                      #Pegando o indice do produto
                      if produto in Produtos_df['Nome do Produto'].tolist():
                        for i in range(len(Produtos_df)):
                          if Produtos_df.at[i, 'Nome do Produto'] == produto:
                            break
                          else:
                            indice_produto += 1
                        
    
                        clear()
    
                        #perguntando sobre a quantidade que vai entrar
                        print("Qual a quantidade a ser retirada do produto?")
                        nova_quantidade = int(input(''))
                        if(nova_quantidade > Produtos_df.at[indice_produto,'Quantidade']):
                          print("Valor maior do que tem no estoque")
                          delay(1.5)
                          continue
    
                        #Somando com a quantidade anterior
                        valor_anterior = Produtos_df.at[indice_produto,'Quantidade']
                        quantidade_produto = valor_anterior - nova_quantidade
    
                        #Pegando data e hora brasilia
                        brasilia_tz = tz.gettz('America/Sao_Paulo')
    
                        # Obtendo a data e a hora atuais em Brasília
                        brasilia_time = datetime.now(brasilia_tz)
    
                        # Salvando a data e a hora em um DataFrame
                        data = {
                            'Data': [brasilia_time.strftime("%d/%m/%Y")],
                            'Hora': [brasilia_time.strftime("%H:%M:%S")]
                        }
    
                        #Colocando no DataFrame
                        Produtos_df.at[indice_produto,'Quantidade'] = quantidade_produto

                        #Adicionando no relatorio do gerente
                        relatorio_df.loc[len(relatorio_df)] = [produto, -abs(nova_quantidade), quantidade_produto, data]
                        relatorio_df.to_csv('Gerente.csv', index=False)
                        Produtos_df.to_csv('Produto.csv', index=False)
                        clear()
                        print("Produto Atualizado com sucesso")
                        print(Produtos_df)
                        input('')
                        clear()
                        #Caso o produto não for encontrado
                      else:
                        print("Produto não encontrado")
                        delay(2.5)
                    else:
                      break
                  #Outra resposta
                else:
                  break

            #'Gerente'
            elif Usuario_df['Função'][indice] == 'GR':
              while True:
                clear()
                imprimir("Gerente")
                print("O que quer fazer?\n'1.Ver Relatorio'\n'2.sair")
                resposta = int(input(''))
                if (resposta == 1):
                  clear()
                  print(relatorio_df)
                  input()
                else:
                  break

          #Acesso negado senha errada
          else:
            clear()
            imprimir('Negado')
            print('Senha errada')
            delay(2.5)
            clear()

        #Acesso negado usuario errado
        else:
          clear()
          imprimir('Negado')
          print('Usuario errado')
          delay(2.5)
          clear()

      
      else:
        #Salvando arquivo DataFrame no CSV
        Usuario_df.to_csv('Login.csv', index=False)
        Produtos_df.to_csv('Produto.csv', index=False)
        relatorio_df.to_csv('Gerente.csv', index=False)
        break

  #Sair
  else:
    #Salvando arquivo DataFrame no CSV
    Usuario_df.to_csv('Login.csv', index=False)
    Produtos_df.to_csv('Produto.csv', index=False)
    relatorio_df.to_csv('Gerente.csv', index=False)
    break